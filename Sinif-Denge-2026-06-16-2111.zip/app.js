(function () {
  "use strict";

  const STORAGE_KEY = "sinif-denge-v1";
  const Engine = window.SinifDengeMotoru;
  const Csv = window.SinifDengeCsv;
  const Academic = window.SinifDengeAkademik;
  const academicLabels = Academic.labels;
  const viewTitles = {
    students: "Öğrenci Listesi",
    requests: "Veli İstekleri",
    distribution: "Dağıtım Ayarları",
    results: "Yeni Sınıflar",
  };

  let state = loadState();
  let toastTimer = null;
  let draggedStudentId = null;
  let pendingRequestRows = [];
  const classSorts = {};

  const el = (id) => document.getElementById(id);
  const elements = {
    pageTitle: el("pageTitle"),
    saveState: el("saveState"),
    navStudentCount: el("navStudentCount"),
    navRequestCount: el("navRequestCount"),
    studentTotal: el("studentTotal"),
    genderTotal: el("genderTotal"),
    academicTotal: el("academicTotal"),
    behaviorTotal: el("behaviorTotal"),
    oldClassSummary: el("oldClassSummary"),
    studentTableBody: el("studentTableBody"),
    studentEmptyState: el("studentEmptyState"),
    studentSearch: el("studentSearch"),
    oldClassFilter: el("oldClassFilter"),
    inlineEditor: el("inlineEditor"),
    inlineEditorTitle: el("inlineEditorTitle"),
    inlineEditorControl: el("inlineEditorControl"),
    studentDialog: el("studentDialog"),
    studentForm: el("studentForm"),
    studentDialogTitle: el("studentDialogTitle"),
    studentId: el("studentId"),
    studentName: el("studentName"),
    studentGender: el("studentGender"),
    studentOldClass: el("studentOldClass"),
    studentAcademic: el("studentAcademic"),
    academicOutput: el("academicOutput"),
    studentBehavior: el("studentBehavior"),
    studentNotes: el("studentNotes"),
    requestForm: el("requestForm"),
    requestStudentA: el("requestStudentA"),
    requestChoices: [
      el("requestChoice1"),
      el("requestChoice2"),
      el("requestChoice3"),
      el("requestChoice4"),
      el("requestChoice5"),
    ],
    requestType: el("requestType"),
    requestPriority: el("requestPriority"),
    requestNote: el("requestNote"),
    addRequestButton: el("addRequestButton"),
    requestCsvInput: el("requestCsvInput"),
    requestMatchDialog: el("requestMatchDialog"),
    requestMatchForm: el("requestMatchForm"),
    requestMatchList: el("requestMatchList"),
    requestMatchNotice: el("requestMatchNotice"),
    clearUnmatchedChoicesButton: el("clearUnmatchedChoicesButton"),
    requestList: el("requestList"),
    requestEmptyState: el("requestEmptyState"),
    requestListSummary: el("requestListSummary"),
    requestConflictPanel: el("requestConflictPanel"),
    clearRequestsButton: el("clearRequestsButton"),
    classCount: el("classCount"),
    classPrefix: el("classPrefix"),
    criterionGender: el("criterionGender"),
    criterionAcademic: el("criterionAcademic"),
    criterionOldClass: el("criterionOldClass"),
    criterionSameOldClassGender: el("criterionSameOldClassGender"),
    criterionBehavior: el("criterionBehavior"),
    classNamePreview: el("classNamePreview"),
    readyStudents: el("readyStudents"),
    readyRequests: el("readyRequests"),
    readyOldClasses: el("readyOldClasses"),
    solveReadiness: el("solveReadiness"),
    solveTitle: el("solveTitle"),
    solveButton: el("solveButton"),
    noResults: el("noResults"),
    resultsContent: el("resultsContent"),
    qualityRing: el("qualityRing"),
    qualityScore: el("qualityScore"),
    resultMetrics: el("resultMetrics"),
    warningPanel: el("warningPanel"),
    warningSummary: el("warningSummary"),
    warningList: el("warningList"),
    classGrid: el("classGrid"),
    csvInput: el("csvInput"),
    resultCsvInput: el("resultCsvInput"),
    toast: el("toast"),
    solvingOverlay: el("solvingOverlay"),
    privacyDialog: el("privacyDialog"),
    acceptPrivacyButton: el("acceptPrivacyButton"),
  };

  function defaultState() {
    return {
      dataVersion: 5,
      students: [],
      requests: [],
      settings: {
        classCount: "",
        classPrefix: "",
        criteria: {
          gender: true,
          academic: true,
          oldClass: true,
          sameOldClassGender: true,
          behavior: true,
        },
      },
      assignment: null,
      activeView: "students",
    };
  }

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      if (!saved || !Array.isArray(saved.students)) return defaultState();
      const loaded = {
        ...defaultState(),
        ...saved,
        settings: {
          ...defaultState().settings,
          ...(saved.settings || {}),
          criteria: {
            ...defaultState().settings.criteria,
            ...(saved.settings?.criteria || {}),
          },
        },
      };
      if (Number(saved.dataVersion || 1) < 2) {
        loaded.students = loaded.students.map((student) => {
          if (student.behavior) return student;
          const repaired = Csv.resolveBehaviorAndNotes("", student.notes);
          return { ...student, ...repaired };
        });
        loaded.dataVersion = 2;
      }
      if (Number(saved.dataVersion || 1) < 3) {
        loaded.students = loaded.students.map((student) => ({
          ...student,
          academic: Academic.migrateLegacy(student.academic),
        }));
        loaded.assignment = null;
        loaded.dataVersion = 3;
      }
      if (Number(saved.dataVersion || 1) < 4) {
        loaded.requests = loaded.requests
          .map((request) => ({
            ...request,
            choices: Array.isArray(request.choices)
              ? request.choices
              : [request.studentB].filter(Boolean),
          }))
          .filter(
            (request) =>
              request.studentA && request.choices.length > 0
          );
        loaded.assignment = null;
        loaded.dataVersion = 4;
      }
      if (Number(saved.dataVersion || 1) < 5) {
        loaded.requests = loaded.requests.map((request) => ({
          ...request,
          priority: ["hard", "auto", "soft"].includes(request.priority)
            ? request.priority
            : "auto",
        }));
        loaded.assignment = null;
        loaded.dataVersion = 5;
      }
      localStorage.setItem(STORAGE_KEY, JSON.stringify(loaded));
      return loaded;
    } catch (error) {
      return defaultState();
    }
  }

  function saveState() {
    elements.saveState.textContent = "Kaydediliyor...";
    elements.saveState.classList.add("saving");
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    window.setTimeout(() => {
      elements.saveState.textContent = "Kaydedildi";
      elements.saveState.classList.remove("saving");
    }, 250);
  }

  function invalidateResult() {
    state.assignment = null;
  }

  function validClassCount(value = state.settings.classCount) {
    if (String(value ?? "").trim() === "") return null;
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) return null;
    return Math.max(2, Math.min(12, Math.round(parsed)));
  }

  function classPrefixValue(value = state.settings.classPrefix) {
    return String(value ?? "").trim();
  }

  function uid(prefix) {
    if (window.crypto && window.crypto.randomUUID) {
      return `${prefix}-${window.crypto.randomUUID()}`;
    }
    return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function initials(name) {
    return String(name)
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0])
      .join("")
      .toLocaleUpperCase("tr");
  }

  function showToast(message) {
    window.clearTimeout(toastTimer);
    elements.toast.textContent = message;
    elements.toast.classList.add("show");
    toastTimer = window.setTimeout(() => {
      elements.toast.classList.remove("show");
    }, 2800);
  }

  function navigate(view) {
    const safeView = viewTitles[view] ? view : "students";
    state.activeView = safeView;
    document.querySelectorAll(".view").forEach((section) => {
      section.classList.toggle("active", section.id === `${safeView}View`);
    });
    document.querySelectorAll(".nav-item").forEach((button) => {
      button.classList.toggle("active", button.dataset.view === safeView);
    });
    elements.pageTitle.textContent = viewTitles[safeView];
    document.querySelector(".sidebar").classList.remove("open");
    if (safeView === "results") renderResults();
    saveState();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function renderAll() {
    renderSummary();
    renderStudentFilters();
    renderStudents();
    renderRequestSelectors();
    renderRequests();
    renderDistribution();
    renderResults();
    elements.navStudentCount.textContent = state.students.length;
    elements.navRequestCount.textContent = state.requests.length;
    navigate(state.activeView || "students");
  }

  function renderSummary() {
    const female = state.students.filter(
      (student) => student.gender === "K"
    ).length;
    const male = state.students.length - female;
    const academicAverage = state.students.length
      ? state.students.reduce(
          (sum, student) => sum + Academic.normalize(student.academic),
          0
        ) / state.students.length
      : 0;
    const behavior = state.students.filter(
      (student) => student.behavior
    ).length;
    const oldClasses = new Set(
      state.students.map((student) => student.oldClass).filter(Boolean)
    );

    elements.studentTotal.textContent = state.students.length;
    elements.genderTotal.textContent = `${female} / ${male}`;
    elements.academicTotal.textContent = academicAverage
      ? academicAverage.toFixed(2)
      : "-";
    elements.behaviorTotal.textContent = behavior;
    elements.oldClassSummary.textContent = oldClasses.size
      ? `${oldClasses.size} eski şubeden`
      : "Henüz veri yok";
  }

  function renderStudentFilters() {
    const selected = elements.oldClassFilter.value;
    const oldClasses = [...new Set(state.students.map((s) => s.oldClass))]
      .filter(Boolean)
      .sort((a, b) => a.localeCompare(b, "tr"));
    elements.oldClassFilter.innerHTML =
      '<option value="">Tüm eski sınıflar</option>' +
      oldClasses
        .map(
          (oldClass) =>
            `<option value="${escapeHtml(oldClass)}">${escapeHtml(
              oldClass
            )}</option>`
        )
        .join("");
    if (oldClasses.includes(selected)) elements.oldClassFilter.value = selected;
  }

  function renderStudents() {
    const query = elements.studentSearch.value
      .trim()
      .toLocaleLowerCase("tr");
    const oldClass = elements.oldClassFilter.value;
    const filtered = state.students
      .filter((student) => {
        const searchable =
          `${student.name} ${student.oldClass}`.toLocaleLowerCase("tr");
        return (
          (!query || searchable.includes(query)) &&
          (!oldClass || student.oldClass === oldClass)
        );
      })
      .sort((a, b) => a.name.localeCompare(b.name, "tr"));

    elements.studentTableBody.innerHTML = filtered
      .map(
        (student) => `
          <tr class="${student.gender === "E" ? "gender-e" : "gender-k"}">
            <td>
              <button
                class="editable-cell student-name"
                type="button"
                data-inline-edit="name"
                data-student-id="${escapeHtml(student.id)}"
                title="Öğrenci adını düzenle"
              >
                <span class="avatar">${escapeHtml(initials(student.name))}</span>
                <span>
                  <strong>${escapeHtml(student.name)}</strong>
                  <small>${student.gender === "K" ? "Kız" : "Erkek"}</small>
                </span>
              </button>
            </td>
            <td>
              <button
                class="editable-cell editable-value"
                type="button"
                data-inline-edit="gender"
                data-student-id="${escapeHtml(student.id)}"
                title="Cinsiyeti düzenle"
              >${student.gender === "K" ? "Kız" : "Erkek"}</button>
            </td>
            <td>
              <button
                class="editable-cell"
                type="button"
                data-inline-edit="oldClass"
                data-student-id="${escapeHtml(student.id)}"
                title="Eski sınıfı düzenle"
              ><span class="tag">${escapeHtml(student.oldClass)}</span></button>
            </td>
            <td>
              <button
                class="editable-cell"
                type="button"
                data-inline-edit="academic"
                data-student-id="${escapeHtml(student.id)}"
                title="Akademik puanı düzenle"
              ><span class="academic-badge">${escapeHtml(
                Academic.format(student.academic)
              )}</span></button>
            </td>
            <td>
              <button
                class="editable-cell editable-value"
                type="button"
                data-inline-edit="behavior"
                data-student-id="${escapeHtml(student.id)}"
                title="Davranış durumunu düzenle"
              >${
                student.behavior
                  ? '<span class="behavior-badge">İşaretli</span>'
                  : '<span class="muted">Yok</span>'
              }</button>
            </td>
            <td>
              <button
                class="editable-cell editable-note"
                type="button"
                data-inline-edit="notes"
                data-student-id="${escapeHtml(student.id)}"
                title="Notu düzenle"
              >${escapeHtml(student.notes || "-")}</button>
            </td>
            <td class="actions-cell">
              <button class="icon-button danger" data-delete-student="${escapeHtml(
                student.id
              )}">Sil</button>
            </td>
          </tr>
        `
      )
      .join("");

    const table = elements.studentTableBody.closest("table");
    const showEmpty = state.students.length === 0;
    table.hidden = showEmpty;
    elements.studentEmptyState.hidden = !showEmpty;
    if (!showEmpty && filtered.length === 0) {
      elements.studentTableBody.innerHTML = `
        <tr><td colspan="7" class="muted">Aramanızla eşleşen öğrenci bulunamadı.</td></tr>
      `;
    }
  }

  function openInlineEditor(button) {
    const student = studentById(button.dataset.studentId);
    const field = button.dataset.inlineEdit;
    if (!student || !field) return;

    const titles = {
      name: "Öğrenci adını düzenle",
      gender: "Cinsiyeti düzenle",
      oldClass: "Eski sınıfı düzenle",
      academic: "Akademik puanı düzenle",
      behavior: "Davranış durumunu düzenle",
      notes: "Öğrenci notunu düzenle",
    };
    let control = "";
    if (field === "name") {
      control = `<input name="value" type="text" required value="${escapeHtml(
        student.name
      )}" autocomplete="off" />`;
    } else if (field === "gender") {
      control = `
        <select name="value">
          <option value="K" ${student.gender === "K" ? "selected" : ""}>Kız</option>
          <option value="E" ${student.gender === "E" ? "selected" : ""}>Erkek</option>
        </select>`;
    } else if (field === "oldClass") {
      control = `<input name="value" type="text" required maxlength="12" value="${escapeHtml(
        student.oldClass
      )}" autocomplete="off" />`;
    } else if (field === "academic") {
      control = `
        <select name="value">
          ${Object.entries(academicLabels)
            .map(
              ([value, label]) =>
                `<option value="${value}" ${
                  Number(student.academic) === Number(value) ? "selected" : ""
                }>${value} - ${escapeHtml(label)}</option>`
            )
            .join("")}
        </select>`;
    } else if (field === "behavior") {
      control = `
        <select name="value">
          <option value="false" ${student.behavior ? "" : "selected"}>Yok</option>
          <option value="true" ${student.behavior ? "selected" : ""}>İşaretli</option>
        </select>`;
    } else if (field === "notes") {
      control = `<textarea name="value" rows="3" placeholder="Not ekleyin...">${escapeHtml(
        student.notes || ""
      )}</textarea>`;
    }

    elements.inlineEditor.dataset.studentId = student.id;
    elements.inlineEditor.dataset.field = field;
    elements.inlineEditorTitle.textContent = titles[field];
    elements.inlineEditorControl.innerHTML = control;
    elements.inlineEditor.hidden = false;

    const rect = button.getBoundingClientRect();
    const editorWidth = elements.inlineEditor.offsetWidth;
    const editorHeight = elements.inlineEditor.offsetHeight;
    const left = Math.max(
      10,
      Math.min(rect.left, window.innerWidth - editorWidth - 10)
    );
    const spaceBelow = window.innerHeight - rect.bottom;
    const top =
      spaceBelow >= editorHeight + 10
        ? rect.bottom + 6
        : Math.max(10, rect.top - editorHeight - 6);
    elements.inlineEditor.style.left = `${left}px`;
    elements.inlineEditor.style.top = `${top}px`;
    const input = elements.inlineEditor.querySelector(
      "input, select, textarea"
    );
    if (input) {
      input.focus();
      if (input.select && input.tagName !== "SELECT") input.select();
    }
  }

  function closeInlineEditor() {
    elements.inlineEditor.hidden = true;
    elements.inlineEditorControl.innerHTML = "";
    delete elements.inlineEditor.dataset.studentId;
    delete elements.inlineEditor.dataset.field;
  }

  function saveInlineEdit(event) {
    event.preventDefault();
    const student = studentById(elements.inlineEditor.dataset.studentId);
    const field = elements.inlineEditor.dataset.field;
    const control = elements.inlineEditor.querySelector("[name='value']");
    if (!student || !field || !control) return;
    let value = control.value.trim();
    if ((field === "name" || field === "oldClass") && !value) {
      showToast("Bu alan boş bırakılamaz.");
      return;
    }
    if (field === "oldClass") value = value.toLocaleUpperCase("tr");
    if (field === "academic") value = Number(value);
    if (field === "behavior") value = value === "true";
    student[field] = value;
    invalidateResult();
    closeInlineEditor();
    saveState();
    renderSummary();
    renderStudentFilters();
    renderStudents();
    renderRequestSelectors();
    renderRequests();
    renderDistribution();
    renderResults();
    showToast("Öğrenci bilgisi güncellendi.");
  }

  function openStudentDialog(student) {
    elements.studentForm.reset();
    elements.studentId.value = student ? student.id : "";
    elements.studentName.value = student ? student.name : "";
    elements.studentGender.value = student ? student.gender : "K";
    elements.studentOldClass.value = student ? student.oldClass : "";
    elements.studentAcademic.value = student
      ? Academic.normalize(student.academic)
      : 2;
    elements.studentBehavior.checked = student ? student.behavior : false;
    elements.studentNotes.value = student ? student.notes || "" : "";
    elements.studentDialogTitle.textContent = student
      ? "Öğrenciyi düzenle"
      : "Yeni öğrenci";
    renderAcademicOutput();
    elements.studentDialog.showModal();
    window.setTimeout(() => elements.studentName.focus(), 50);
  }

  function renderAcademicOutput() {
    const value = Number(elements.studentAcademic.value);
    elements.academicOutput.textContent = Academic.format(value);
  }

  function saveStudent(event) {
    event.preventDefault();
    if (event.submitter && event.submitter.value === "cancel") {
      elements.studentDialog.close();
      return;
    }
    const id = elements.studentId.value || uid("ogr");
    const student = {
      id,
      name: elements.studentName.value.trim(),
      gender: elements.studentGender.value,
      oldClass: elements.studentOldClass.value.trim().toLocaleUpperCase("tr"),
      academic: Academic.normalize(elements.studentAcademic.value),
      behavior: elements.studentBehavior.checked,
      notes: elements.studentNotes.value.trim(),
    };
    if (!student.name || !student.oldClass) {
      showToast("Ad soyad ve eski sınıf alanları gereklidir.");
      return;
    }
    const index = state.students.findIndex((item) => item.id === id);
    if (index >= 0) state.students[index] = student;
    else state.students.push(student);
    invalidateResult();
    elements.studentDialog.close();
    saveState();
    renderAll();
    showToast(index >= 0 ? "Öğrenci güncellendi." : "Öğrenci eklendi.");
  }

  function deleteStudent(id) {
    const student = state.students.find((item) => item.id === id);
    if (!student) return;
    const relatedRequests = state.requests.filter(
      (request) =>
        request.studentA === id ||
        request.choices.includes(id)
    ).length;
    const detail = relatedRequests
      ? ` Bu öğrenciye bağlı ${relatedRequests} veli isteği de silinecek.`
      : "";
    if (!window.confirm(`${student.name} silinsin mi?${detail}`)) return;
    state.students = state.students.filter((item) => item.id !== id);
    state.requests = state.requests
      .filter((request) => request.studentA !== id)
      .map((request) => ({
        ...request,
        choices: request.choices.filter((choiceId) => choiceId !== id),
      }))
      .filter((request) => request.choices.length > 0);
    invalidateResult();
    saveState();
    renderAll();
    showToast("Öğrenci silindi.");
  }

  function renderRequestSelectors() {
    const currentA = elements.requestStudentA.value;
    const currentChoices = elements.requestChoices.map(
      (select) => select.value
    );
    const options = state.students
      .slice()
      .sort((a, b) => a.name.localeCompare(b.name, "tr"))
      .map(
        (student) =>
          `<option value="${escapeHtml(student.id)}">${escapeHtml(
            student.name
          )} (${escapeHtml(student.oldClass)})</option>`
      )
      .join("");
    const placeholder =
      state.students.length < 2
        ? '<option value="">En az iki öğrenci ekleyin</option>'
        : '<option value="">Öğrenci seçin</option>';
    const optionalPlaceholder =
      state.students.length < 2
        ? '<option value="">En az iki öğrenci ekleyin</option>'
        : '<option value="">Tercih eklenmedi</option>';
    elements.requestStudentA.innerHTML = placeholder + options;
    elements.requestChoices.forEach((select, index) => {
      select.innerHTML =
        (index === 0 ? placeholder : optionalPlaceholder) + options;
    });
    if (state.students.some((item) => item.id === currentA)) {
      elements.requestStudentA.value = currentA;
    }
    currentChoices.forEach((choiceId, index) => {
      if (state.students.some((item) => item.id === choiceId)) {
        elements.requestChoices[index].value = choiceId;
      }
    });
    elements.requestStudentA.disabled = state.students.length < 2;
    elements.requestChoices.forEach((select) => {
      select.disabled = state.students.length < 2;
    });
    elements.addRequestButton.disabled = state.students.length < 2;
  }

  function studentById(id) {
    return state.students.find((student) => student.id === id);
  }

  function renderRequests() {
    const analysis = getAnalysis();
    const outcomes = new Map(
      (analysis ? analysis.requestOutcomes : []).map((outcome) => [
        outcome.requestId,
        outcome,
      ])
    );
    elements.requestList.innerHTML = state.requests
      .map((request) => {
        const studentA = studentById(request.studentA);
        const choices = request.choices
          .map((choiceId) => studentById(choiceId))
          .filter(Boolean);
        if (!studentA || choices.length === 0) return "";
        const together = request.type === "together";
        const outcome = outcomes.get(request.id);
        return `
          <article class="request-item">
            <div>
              <div class="request-people">
                <strong>${escapeHtml(studentA.name)}</strong>
                <select
                  class="request-inline-select ${
                    together ? "together" : "apart"
                  }"
                  data-request-id="${escapeHtml(request.id)}"
                  data-request-field="type"
                  aria-label="İstek türü"
                >
                  <option value="together" ${
                    together ? "selected" : ""
                  }>Birlikte</option>
                  <option value="apart" ${
                    together ? "" : "selected"
                  }>Ayrı</option>
                </select>
                <select
                  class="request-inline-select priority"
                  data-request-id="${escapeHtml(request.id)}"
                  data-request-field="priority"
                  aria-label="İstek önceliği"
                >
                  <option value="auto" ${
                    request.priority === "auto" ? "selected" : ""
                  }>Otomatik</option>
                  <option value="hard" ${
                    request.priority === "hard" ? "selected" : ""
                  }>Kesin</option>
                  <option value="soft" ${
                    request.priority === "soft" ? "selected" : ""
                  }>Tercih</option>
                </select>
              </div>
              <ol class="preference-list">
                ${choices
                  .map(
                    (student, index) => `
                      <li class="${
                        outcome &&
                        outcome.satisfied &&
                        outcome.satisfiedIds.includes(student.id)
                          ? "fulfilled"
                          : ""
                      }">
                        <span>${index + 1}</span>
                        ${escapeHtml(student.name)}
                        ${
                          outcome &&
                          outcome.satisfied &&
                          outcome.satisfiedIds.includes(student.id)
                            ? "<b>Karşılandı</b>"
                            : ""
                        }
                      </li>
                    `
                  )
                  .join("")}
              </ol>
              <p>${escapeHtml(request.note || "Açıklama eklenmedi.")}</p>
            </div>
            <button class="icon-button danger" data-delete-request="${escapeHtml(
              request.id
            )}">Sil</button>
          </article>
        `;
      })
      .join("");
    const conflicts = Engine.detectRequestConflicts(
      state.requests,
      state.students
    );
    elements.requestConflictPanel.hidden = conflicts.length === 0;
    elements.requestConflictPanel.innerHTML = conflicts.length
      ? `<strong>Çelişen istek bulundu</strong>${conflicts
          .map((conflict) => `<p>${escapeHtml(conflict.message)}</p>`)
          .join("")}`
      : "";
    elements.requestEmptyState.hidden = state.requests.length > 0;
    elements.requestList.hidden = state.requests.length === 0;
    elements.clearRequestsButton.disabled = state.requests.length === 0;
    const hardCount = state.requests.filter(
      (request) => request.priority === "hard"
    ).length;
    const autoCount = state.requests.filter(
      (request) => request.priority === "auto"
    ).length;
    elements.requestListSummary.textContent = state.requests.length
      ? `${state.requests.length} istek var; ${hardCount} kesin, ${autoCount} otomatik.`
      : "Henüz istek girilmedi.";
  }

  function addRequest(event) {
    event.preventDefault();
    const studentA = elements.requestStudentA.value;
    const rawChoices = elements.requestChoices
      .map((select) => select.value)
      .filter(Boolean);
    const choices = [...new Set(rawChoices)];
    const type = elements.requestType.value;
    if (!studentA || choices.length === 0) {
      showToast("Tercihte bulunan öğrenciyi ve en az ilk tercihi seçin.");
      return;
    }
    if (choices.includes(studentA)) {
      showToast("Öğrenci kendisini tercih edemez.");
      return;
    }
    if (choices.length !== rawChoices.length) {
      showToast("Aynı öğrenci birden fazla tercih sırasına yazılamaz.");
      return;
    }
    const duplicate = state.requests.some(
      (request) =>
        request.studentA === studentA &&
        request.type === type &&
        request.choices.length === choices.length &&
        request.choices.every(
          (choiceId, index) => choiceId === choices[index]
        )
    );
    if (duplicate) {
      showToast("Bu istek daha önce eklenmiş.");
      return;
    }
    state.requests.push({
      id: uid("istek"),
      studentA,
      choices,
      type,
      priority: elements.requestPriority.value,
      note: elements.requestNote.value.trim(),
    });
    elements.requestForm.reset();
    invalidateResult();
    saveState();
    renderAll();
    state.activeView = "requests";
    navigate("requests");
    showToast("Veli isteği eklendi.");
  }

  function updateRequestField(id, field, value) {
    const request = state.requests.find((item) => item.id === id);
    if (!request || !["type", "priority"].includes(field)) return;
    request[field] = value;
    invalidateResult();
    saveState();
    renderRequests();
    renderDistribution();
    renderResults();
    const conflicts = Engine.detectRequestConflicts(
      state.requests,
      state.students
    );
    showToast(
      conflicts.length
        ? "İstek güncellendi; çelişki uyarısını kontrol edin."
        : "İstek güncellendi."
    );
  }

  function deleteRequest(id) {
    state.requests = state.requests.filter((request) => request.id !== id);
    invalidateResult();
    saveState();
    renderAll();
    state.activeView = "requests";
    navigate("requests");
    showToast("İstek silindi.");
  }

  function clearRequests() {
    if (!state.requests.length) return;
    const confirmed = window.confirm(
      `${state.requests.length} veli isteğinin tamamı silinsin mi?`
    );
    if (!confirmed) return;

    state.requests = [];
    invalidateResult();
    saveState();
    renderAll();
    state.activeView = "requests";
    navigate("requests");
    showToast("Tüm veli istekleri silindi.");
  }


  function renderDistribution() {
    elements.classCount.value = state.settings.classCount ?? "";
    elements.classPrefix.value = classPrefixValue();
    elements.criterionGender.value = String(
      state.settings.criteria.gender
    );
    elements.criterionAcademic.value = String(
      state.settings.criteria.academic
    );
    elements.criterionOldClass.value = String(
      state.settings.criteria.oldClass
    );
    elements.criterionSameOldClassGender.value = String(
      state.settings.criteria.sameOldClassGender
    );
    elements.criterionBehavior.value = String(
      state.settings.criteria.behavior
    );
    const classCount = validClassCount();
    const classPrefix = classPrefixValue();
    const hasClassSetup = Boolean(classCount && classPrefix);
    elements.classNamePreview.innerHTML = hasClassSetup
      ? Engine.buildClassNames(
          classCount,
          classPrefix,
          state.settings.classNames
        )
          .map((name) => `<span>${escapeHtml(name)}</span>`)
          .join("")
      : '<span>Yeni sınıf sayısı ve sınıf adı başlangıcı girin.</span>';
    const oldClasses = new Set(state.students.map((student) => student.oldClass));
    elements.readyStudents.textContent = state.students.length;
    elements.readyRequests.textContent = state.requests.length;
    elements.readyOldClasses.textContent = oldClasses.size;
    elements.solveButton.disabled = !hasClassSetup || state.students.length < classCount;
    elements.solveTitle.textContent = hasClassSetup
      ? `${classCount} dengeli sınıfı saniyeler içinde oluşturun`
      : "Dağıtım için sınıf bilgilerini girin";
    elements.solveReadiness.textContent =
      !hasClassSetup
        ? "Yeni sınıf sayısı ve sınıf adı başlangıcı boş bırakılamaz."
        : state.students.length < classCount
        ? `Dağıtım için en az ${classCount} öğrenci gereklidir.`
        : `${state.students.length} öğrenci, ${classCount} yeni sınıfa etkin ölçütler birlikte değerlendirilerek dağıtılacak.`;
  }

  function updateSettings() {
    const previousCount = state.settings.classCount;
    const previousPrefix = state.settings.classPrefix;
    state.settings.classCount = validClassCount(elements.classCount.value) || "";
    state.settings.classPrefix = classPrefixValue(elements.classPrefix.value);
    if (
      previousCount !== state.settings.classCount ||
      previousPrefix !== state.settings.classPrefix
    ) {
      delete state.settings.classNames;
    }
    state.settings.criteria = {
      gender: elements.criterionGender.value === "true",
      academic: elements.criterionAcademic.value === "true",
      oldClass: elements.criterionOldClass.value === "true",
      sameOldClassGender:
        elements.criterionSameOldClassGender.value === "true",
      behavior: elements.criterionBehavior.value === "true",
    };
    invalidateResult();
    saveState();
    renderDistribution();
    renderResults();
  }

  function solveClasses() {
    const classCount = validClassCount();
    const classPrefix = classPrefixValue();
    if (!classCount) {
      showToast("Yeni sınıf sayısını girin.");
      return;
    }
    if (!classPrefix) {
      showToast("Sınıf adı başlangıcını girin.");
      return;
    }
    if (state.students.length < classCount) {
      showToast("Sınıf sayısından daha fazla öğrenci eklemelisiniz.");
      return;
    }
    elements.solvingOverlay.hidden = false;
    window.setTimeout(() => {
      try {
        const result = Engine.solve(state.students, state.requests, {
          ...state.settings,
          classCount,
          classPrefix,
          seed: Date.now(),
        });
        state.assignment = result.assignment;
        saveState();
        renderResults();
        navigate("results");
        showToast("Dengeli sınıflar oluşturuldu.");
      } catch (error) {
        showToast(error.message || "Dağıtım sırasında bir sorun oluştu.");
      } finally {
        elements.solvingOverlay.hidden = true;
      }
    }, 80);
  }

  function getAnalysis() {
    if (!state.assignment) return null;
    const classCount = validClassCount() || Number(state.settings.classCount) || 6;
    const classNames = Engine.buildClassNames(
      classCount,
      classPrefixValue(),
      state.settings.classNames
    );
    return Engine.analyze(
      state.students,
      state.requests,
      state.assignment,
      {
        ...state.settings,
        classNames,
      }
    );
  }

  function sortedClassStudents(classInfo) {
    const sortType = classSorts[classInfo.index] || "name";
    return classInfo.students.slice().sort((a, b) => {
      if (sortType === "gender") {
        return (
          (a.gender === "K" ? 0 : 1) -
            (b.gender === "K" ? 0 : 1) ||
          a.name.localeCompare(b.name, "tr")
        );
      }
      if (sortType === "oldClass") {
        return (
          a.oldClass.localeCompare(b.oldClass, "tr", {
            numeric: true,
          }) || a.name.localeCompare(b.name, "tr")
        );
      }
      if (sortType === "academic") {
        return (
          b.academic - a.academic ||
          a.name.localeCompare(b.name, "tr")
        );
      }
      return a.name.localeCompare(b.name, "tr");
    });
  }

  function oldClassDistributionHtml(oldClasses) {
    return Object.entries(oldClasses)
      .sort(([a], [b]) => a.localeCompare(b, "tr", { numeric: true }))
      .map(
        ([name, count]) =>
          `<span class="old-class-chip"><b>${escapeHtml(
            name
          )}</b><em>${count}</em></span>`
      )
      .join("");
  }

  function renderResults() {
    const analysis = getAnalysis();
    elements.noResults.hidden = Boolean(analysis);
    elements.resultsContent.hidden = !analysis;
    if (!analysis) return;

    elements.qualityScore.textContent = analysis.quality;
    elements.qualityRing.style.setProperty("--score", `${analysis.quality}%`);
    elements.resultMetrics.innerHTML = `
      <article class="metric-card">
        <span>Mevcut farkı</span>
        <strong>${analysis.metrics.sizeSpread}</strong>
        <small>${analysis.metrics.sizeSpread <= 1 ? "Dengeli" : "Kontrol gerekli"}</small>
      </article>
      <article class="metric-card">
        <span>Kız öğrenci farkı</span>
        <strong>${analysis.metrics.femaleSpread}</strong>
        <small>${
          analysis.criteria.gender
            ? analysis.metrics.femaleSpread <= 1
              ? "Dengeli"
              : "Kontrol gerekli"
            : "Kriter etkin değil"
        }</small>
      </article>
      <article class="metric-card">
        <span>Başarı ort. farkı</span>
        <strong>${analysis.metrics.academicSpread.toFixed(2)}</strong>
        <small>${
          analysis.criteria.academic
            ? analysis.metrics.academicSpread <= 0.35
              ? "Dengeli"
              : "Kontrol gerekli"
            : "Kriter etkin değil"
        }</small>
      </article>
      <article class="metric-card">
        <span>Davranış işareti farkı</span>
        <strong>${analysis.metrics.behaviorSpread}</strong>
        <small>${
          analysis.criteria.behavior
            ? analysis.metrics.behaviorSpread <= 1
              ? "Dengeli"
              : "Kontrol gerekli"
            : "Kriter etkin değil"
        }</small>
      </article>
    `;

    elements.warningPanel.classList.toggle(
      "good",
      analysis.violations.length === 0
    );
    elements.warningSummary.textContent = analysis.violations.length
      ? `${analysis.violations.length} nokta gözden geçirilmeli.`
      : "Tüm temel denge kontrolleri başarılı.";
    elements.warningList.className = analysis.violations.length
      ? "warning-list"
      : "";
    elements.warningList.innerHTML = analysis.violations.length
      ? analysis.violations
          .map(
            (warning) => `
              <div class="warning-item ${warning.severity}">
                <strong>${escapeHtml(warning.category)}:</strong>
                <span>${escapeHtml(warning.message)}</span>
              </div>
            `
          )
          .join("")
      : '<div class="all-good">Kesin istekler ve tüm temel denge hedefleri karşılandı.</div>';

    const classOptions = analysis.perClass
      .map(
        (item) =>
          `<option value="${item.index}">${escapeHtml(item.name)}</option>`
      )
      .join("");
    elements.classGrid.innerHTML = analysis.perClass
      .map(
        (classInfo) => `
          <article class="class-card" data-drop-class="${classInfo.index}">
            <header class="class-card-header">
              <span class="class-letter">${escapeHtml(classInfo.name)}</span>
              <div>
                <h3>${escapeHtml(classInfo.name)} Sınıfı</h3>
                <div class="old-class-chips">
                  ${oldClassDistributionHtml(classInfo.oldClasses)}
                </div>
              </div>
              <span class="class-size">${classInfo.size}</span>
            </header>
            <div class="class-stats">
              <div><strong>${classInfo.female} / ${classInfo.male}</strong><span>Kız / Erkek</span></div>
              <div><strong>${classInfo.academicAverage.toFixed(2)}</strong><span>Başarı ort.</span></div>
              <div><strong>${classInfo.behavior}</strong><span>Davranış işareti</span></div>
            </div>
            <div class="class-sort-bar">
              <span>Sırala:</span>
              <button
                type="button"
                class="${
                  classSorts[classInfo.index] === "gender" ? "active" : ""
                }"
                data-sort-class="${classInfo.index}"
                data-sort-type="gender"
              >Kız / Erkek</button>
              <button
                type="button"
                class="${
                  classSorts[classInfo.index] === "oldClass" ? "active" : ""
                }"
                data-sort-class="${classInfo.index}"
                data-sort-type="oldClass"
              >Eski sınıf</button>
              <button
                type="button"
                class="${
                  classSorts[classInfo.index] === "academic" ? "active" : ""
                }"
                data-sort-class="${classInfo.index}"
                data-sort-type="academic"
              >Akademik</button>
            </div>
            <div class="class-students">
              ${sortedClassStudents(classInfo)
                .map(
                  (student) => `
                    <div
                      class="class-student"
                      draggable="true"
                      data-drag-student="${escapeHtml(student.id)}"
                    >
                      <span class="drag-handle" title="Başka sınıfa sürükle">⋮⋮</span>
                      <div class="class-student-info">
                        <strong>${escapeHtml(student.name)}</strong>
                        <small>${student.gender === "K" ? "Kız" : "Erkek"} · ${escapeHtml(
                          student.oldClass
                        )} · ${escapeHtml(Academic.format(student.academic))}${
                          student.behavior ? " · Davranış işaretli" : ""
                        }</small>
                      </div>
                      <select data-move-student="${escapeHtml(
                        student.id
                      )}" aria-label="${escapeHtml(
                        student.name
                      )} için yeni sınıf">
                        ${classOptions}
                      </select>
                    </div>
                  `
                )
                .join("")}
            </div>
          </article>
        `
      )
      .join("");
    document.querySelectorAll("[data-move-student]").forEach((select) => {
      select.value = state.assignment[select.dataset.moveStudent];
    });
  }

  function moveStudent(studentId, classIndex) {
    if (Number(state.assignment[studentId]) === Number(classIndex)) return;
    state.assignment[studentId] = Number(classIndex);
    saveState();
    renderResults();
    showToast("Öğrenci taşındı; denge puanı yeniden hesaplandı.");
  }

  function csvCell(value) {
    let text = String(value ?? "");
    if (/^[=+\-@]/.test(text)) text = `'${text}`;
    return `"${text.replaceAll('"', '""')}"`;
  }

  function downloadFile(filename, content, type) {
    const blob = new Blob(["\ufeff", content], {
      type: type || "text/csv;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function downloadTemplate() {
    const rows = [
      [
        "Ad Soyad",
        "Cinsiyet",
        "Eski Sınıf",
        "Akademik Başarı",
        "Davranış Sorunu",
        "Not",
      ],
      ["Ahmet Yılmaz", "E", "4A", "2 - Orta", "Hayır", ""],
      ["Ayşe Demir", "K", "4B", "3 - İyi", "Evet", "Kısa not"],
    ];
    downloadFile(
      "ogrenci-sablonu.csv",
      rows.map((row) => row.map(csvCell).join(";")).join("\r\n")
    );
  }

  function downloadRequestTemplate() {
    const rows = [
      [
        "Birlikte - Ayrı",
        "Tercihte bulunan öğrenci ismi",
        "1. tercih",
        "2. tercih",
        "3. tercih",
        "4. tercih",
        "5. tercih",
      ],
      [
        "Birlikte",
        "Ahmet Yılmaz",
        "Ayşe Demir",
        "Ali Kaya",
        "",
        "",
        "",
      ],
      ["Ayrı", "Elif Çelik", "Mehmet Can", "", "", "", ""],
    ];
    downloadFile(
      "veli-istekleri-sablonu.csv",
      rows.map((row) => row.map(csvCell).join(";")).join("\r\n")
    );
  }

  function normalizedStudentMatches(name) {
    const normalized = Csv.normalizeHeader(name);
    if (!normalized) return [];
    return state.students.filter(
      (student) => Csv.normalizeHeader(student.name) === normalized
    );
  }

  function studentOptions(selectedId, originalName, allowNone) {
    let heading = "";
    if (!selectedId && originalName) {
      heading = `<option value="__unmatched__" disabled selected>Listede yok: ${escapeHtml(
        originalName
      )}</option>`;
      if (allowNone) {
        heading += '<option value="">Tercih yok</option>';
      }
    } else if (allowNone) {
      heading = '<option value="">Tercih yok</option>';
    } else {
      heading = '<option value="" disabled selected>Öğrenci seçin</option>';
    }
    return (
      heading +
      state.students
        .slice()
        .sort((a, b) => a.name.localeCompare(b.name, "tr"))
        .map(
          (student) =>
            `<option value="${escapeHtml(student.id)}" ${
              student.id === selectedId ? "selected" : ""
            }>${escapeHtml(student.name)} (${escapeHtml(
              student.oldClass
            )})</option>`
        )
        .join("")
    );
  }

  function requestFromImportRow(row) {
    return {
      id: uid("istek"),
      studentA: row.subjectId,
      choices: row.choiceIds.filter(Boolean),
      type: row.type,
      priority: "auto",
      note: "CSV dosyasından aktarıldı.",
    };
  }

  function renderRequestMatchDialog() {
    clearRequestMatchNotice();
    elements.requestMatchList.innerHTML = pendingRequestRows
      .map(
        (row, rowIndex) => `
          <article class="match-row" data-match-row="${rowIndex}">
            <button
              class="button button-danger-ghost match-delete-button"
              type="button"
              data-delete-match-row="${rowIndex}"
            >
              Satırı sil
            </button>
            <label>
              Birlikte / Ayrı
              <select name="type-${rowIndex}">
                <option value="together" ${
                  row.type === "together" ? "selected" : ""
                }>Birlikte</option>
                <option value="apart" ${
                  row.type === "apart" ? "selected" : ""
                }>Ayrı</option>
              </select>
            </label>
            <label>
              Tercihte bulunan öğrenci
              <select
                name="subject-${rowIndex}"
                class="${
                  !row.subjectId && row.subjectName ? "match-unresolved" : ""
                }"
                required
              >
                ${studentOptions(
                  row.subjectId,
                  row.subjectName,
                  false
                )}
              </select>
            </label>
            <div class="match-choices">
              ${row.choiceNames
                .map(
                  (name, choiceIndex) => `
                    <label>
                      ${choiceIndex + 1}. tercih
                      <select
                        name="choice-${rowIndex}-${choiceIndex}"
                        class="${
                          name && !row.choiceIds[choiceIndex]
                            ? "match-unresolved"
                            : ""
                        }"
                      >
                        ${studentOptions(
                          row.choiceIds[choiceIndex],
                          name,
                          true
                        )}
                      </select>
                    </label>
                  `
                )
                .join("")}
            </div>
          </article>
        `
      )
      .join("");
    updateClearUnmatchedChoicesButton();
    if (!elements.requestMatchDialog.open) {
      elements.requestMatchDialog.showModal();
    }
  }

  function importRequestCsv(file) {
    if (!file) return;
    if (state.students.length < 2) {
      showToast("Önce öğrenci listesini ekleyin.");
      elements.requestCsvInput.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const rows = parseCsv(String(reader.result || ""));
        if (rows.length < 2) {
          throw new Error("CSV dosyasında istek bulunamadı.");
        }
        const headers = rows[0].map(Csv.normalizeHeader);
        const findColumn = (...names) => Csv.findColumn(headers, ...names);
        const typeColumn = findColumn(
          "birlikte - ayri",
          "birlikte ayri",
          "istek turu"
        );
        const subjectColumn = findColumn(
          "tercihte bulunan ogrenci ismi",
          "tercihte bulunan ogrenci"
        );
        const choiceColumns = [1, 2, 3, 4, 5].map((number) =>
          findColumn(
            `${number}. tercih`,
            `${number} tercih`
          )
        );
        if (
          typeColumn < 0 ||
          subjectColumn < 0 ||
          choiceColumns[0] < 0
        ) {
          throw new Error(
            'CSV dosyasında "Birlikte - Ayrı", "Tercihte bulunan öğrenci ismi" ve "1. tercih" sütunları gereklidir.'
          );
        }
        const parsed = rows
          .slice(1)
          .map((cells) => {
            const typeText = Csv.normalizeHeader(
              cells[typeColumn] || ""
            );
            const typeValid =
              typeText.includes("birlikte") ||
              typeText.includes("ayri");
            const subjectName = String(
              cells[subjectColumn] || ""
            ).trim();
            const choiceNames = choiceColumns.map((column) =>
              column >= 0 ? String(cells[column] || "").trim() : ""
            );
            const subjectMatches = normalizedStudentMatches(subjectName);
            const choiceMatches = choiceNames.map((name) =>
              name ? normalizedStudentMatches(name) : []
            );
            return {
              type: typeText.includes("ayri") ? "apart" : "together",
              subjectName,
              subjectId:
                subjectMatches.length === 1 ? subjectMatches[0].id : "",
              choiceNames,
              choiceIds: choiceMatches.map((matches) =>
                matches.length === 1 ? matches[0].id : ""
              ),
              hasMismatch:
                !typeValid ||
                subjectMatches.length !== 1 ||
                choiceNames.some(
                  (name, index) =>
                    name && choiceMatches[index].length !== 1
                ),
            };
          })
          .filter(
            (row) =>
              row.subjectName && row.choiceNames.some(Boolean)
          );
        if (!parsed.length) {
          throw new Error("Aktarılabilecek geçerli istek bulunamadı.");
        }

        const matched = parsed.filter((row) => !row.hasMismatch);
        pendingRequestRows = parsed.filter((row) => row.hasMismatch);
        state.requests.push(...matched.map(requestFromImportRow));
        if (matched.length) {
          invalidateResult();
          saveState();
          renderRequests();
          renderDistribution();
          renderResults();
        }
        if (pendingRequestRows.length) {
          renderRequestMatchDialog();
          showRequestMatchNotice(
            `${pendingRequestRows.length} satırda öğrenci adı veya tercih eşleşmedi.`,
            "info"
          );
        } else {
          showToast(`${matched.length} veli isteği aktarıldı.`);
        }
      } catch (error) {
        showToast(error.message || "Veli isteği CSV dosyası okunamadı.");
      } finally {
        elements.requestCsvInput.value = "";
      }
    };
    reader.readAsText(file, "UTF-8");
  }

  function requestMatchValue(name) {
    const control = elements.requestMatchForm.elements.namedItem(name);
    return control ? String(control.value || "") : "";
  }

  function clearRequestMatchNotice() {
    elements.requestMatchNotice.hidden = true;
    elements.requestMatchNotice.textContent = "";
    elements.requestMatchNotice.dataset.tone = "";
    elements.requestMatchList
      .querySelectorAll(".match-row-error")
      .forEach((row) => row.classList.remove("match-row-error"));
  }

  function showRequestMatchNotice(message, tone = "error", control = null) {
    elements.requestMatchNotice.textContent = message;
    elements.requestMatchNotice.dataset.tone = tone;
    elements.requestMatchNotice.hidden = false;

    if (control) {
      control.classList.add("match-unresolved");
      control.closest(".match-row")?.classList.add("match-row-error");
      control.scrollIntoView({ behavior: "smooth", block: "center" });
      window.setTimeout(() => control.focus(), 180);
    }
  }

  function unresolvedRequestChoiceControls() {
    return Array.from(
      elements.requestMatchList.querySelectorAll(
        'select[name^="choice-"].match-unresolved'
      )
    ).filter((select) => select.value === "__unmatched__");
  }

  function updateClearUnmatchedChoicesButton() {
    const count = unresolvedRequestChoiceControls().length;
    elements.clearUnmatchedChoicesButton.disabled = count === 0;
    elements.clearUnmatchedChoicesButton.textContent = count
      ? `Hatalı tercihleri Tercih yok yap (${count})`
      : "Hatalı tercihleri Tercih yok yap";
  }

  function clearUnmatchedRequestChoices() {
    const controls = unresolvedRequestChoiceControls();
    if (!controls.length) {
      showRequestMatchNotice("Tercihlerde düzeltilmesi gereken hata kalmadı.", "info");
      return;
    }

    controls.forEach((select) => {
      select.value = "";
      select.classList.remove("match-unresolved");
    });
    updateClearUnmatchedChoicesButton();
    showRequestMatchNotice(
      `${controls.length} hatalı tercih “Tercih yok” olarak ayarlandı.`,
      "success"
    );
  }

  function saveMatchedRequests(event) {
    event.preventDefault();
    clearRequestMatchNotice();
    const corrected = [];
    for (let rowIndex = 0; rowIndex < pendingRequestRows.length; rowIndex += 1) {
      const subjectId = requestMatchValue(`subject-${rowIndex}`);
      const choiceValues = [0, 1, 2, 3, 4].map((choiceIndex) =>
        requestMatchValue(`choice-${rowIndex}-${choiceIndex}`)
      );
      const unresolvedChoiceIndex = choiceValues.findIndex(
        (value) => value === "__unmatched__"
      );
      const choiceIds = choiceValues.filter(Boolean);
      if (!subjectId || subjectId === "__unmatched__") {
        showRequestMatchNotice(
          `${rowIndex + 1}. satır için tercihte bulunan öğrenciyi seçin.`,
          "error",
          elements.requestMatchForm.elements.namedItem(`subject-${rowIndex}`)
        );
        return;
      }
      if (unresolvedChoiceIndex >= 0) {
        showRequestMatchNotice(
          `${rowIndex + 1}. satırdaki ${
            unresolvedChoiceIndex + 1
          }. tercih listede yok. Öğrenci veya Tercih yok seçin.`,
          "error",
          elements.requestMatchForm.elements.namedItem(
            `choice-${rowIndex}-${unresolvedChoiceIndex}`
          )
        );
        return;
      }
      if (!choiceIds.length) {
        showRequestMatchNotice(
          `${rowIndex + 1}. satır için en az bir tercih seçin.`,
          "error",
          elements.requestMatchForm.elements.namedItem(`choice-${rowIndex}-0`)
        );
        return;
      }
      if (choiceIds.includes(subjectId)) {
        const choiceIndex = choiceValues.indexOf(subjectId);
        showRequestMatchNotice(
          `${rowIndex + 1}. satırda öğrenci kendisini tercih edemez.`,
          "error",
          elements.requestMatchForm.elements.namedItem(
            `choice-${rowIndex}-${choiceIndex}`
          )
        );
        return;
      }
      if (new Set(choiceIds).size !== choiceIds.length) {
        const duplicateIndex = choiceValues.findIndex(
          (value, index) => value && choiceValues.indexOf(value) !== index
        );
        showRequestMatchNotice(
          `${rowIndex + 1}. satırda aynı tercih tekrarlanamaz.`,
          "error",
          elements.requestMatchForm.elements.namedItem(
            `choice-${rowIndex}-${duplicateIndex}`
          )
        );
        return;
      }
      corrected.push({
        id: uid("istek"),
        studentA: subjectId,
        choices: choiceIds,
        type:
          requestMatchValue(`type-${rowIndex}`) === "apart"
            ? "apart"
            : "together",
        priority: "auto",
        note: "CSV dosyasından düzeltilerek aktarıldı.",
      });
    }
    state.requests.push(...corrected);
    pendingRequestRows = [];
    elements.requestMatchDialog.close();
    invalidateResult();
    saveState();
    renderRequests();
    renderDistribution();
    renderResults();
    showToast(`${corrected.length} düzeltilmiş veli isteği aktarıldı.`);
  }

  function capturePendingRequestEdits() {
    pendingRequestRows.forEach((row, rowIndex) => {
      const subjectId = requestMatchValue(`subject-${rowIndex}`);
      row.type =
        requestMatchValue(`type-${rowIndex}`) === "apart"
          ? "apart"
          : "together";
      if (subjectId && subjectId !== "__unmatched__") {
        row.subjectId = subjectId;
      }
      row.choiceIds = [0, 1, 2, 3, 4].map((choiceIndex) => {
        const value = requestMatchValue(
          `choice-${rowIndex}-${choiceIndex}`
        );
        if (value === "__unmatched__") {
          return row.choiceIds[choiceIndex] || "";
        }
        if (!value) row.choiceNames[choiceIndex] = "";
        return value;
      });
    });
  }

  function deletePendingRequestRow(rowIndex) {
    if (
      !Number.isInteger(rowIndex) ||
      rowIndex < 0 ||
      rowIndex >= pendingRequestRows.length
    ) {
      return;
    }
    capturePendingRequestEdits();
    pendingRequestRows.splice(rowIndex, 1);
    if (!pendingRequestRows.length) {
      elements.requestMatchDialog.close();
      showToast("Düzeltilecek istek satırı kalmadı.");
      return;
    }
    renderRequestMatchDialog();
    showToast("İstek satırı silindi.");
  }

  function exportResults() {
    const analysis = getAnalysis();
    if (!analysis) return;
    const rows = [
      [
        "Yeni Sınıf",
        "Ad Soyad",
        "Cinsiyet",
        "Eski Sınıf",
        "Akademik Başarı",
        "Davranış Sorunu",
        "Not",
      ],
    ];
    analysis.perClass.forEach((classInfo) => {
      classInfo.students.forEach((student) => {
        rows.push([
          classInfo.name,
          student.name,
          student.gender,
          student.oldClass,
          Academic.format(student.academic),
          student.behavior ? "Evet" : "Hayır",
          student.notes || "",
        ]);
      });
    });
    downloadFile(
      "yeni-sinif-dagitimi.csv",
      rows.map((row) => row.map(csvCell).join(";")).join("\r\n")
    );
  }

  function importPreviousResult(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const rows = parseCsv(String(reader.result || ""));
        if (rows.length < 2) {
          throw new Error("CSV dosyasında sonuç kaydı bulunamadı.");
        }
        const headers = rows[0].map(Csv.normalizeHeader);
        const findColumn = (...names) => Csv.findColumn(headers, ...names);
        const columns = {
          newClass: findColumn("yeni sinif"),
          name: findColumn("ad soyad", "ad", "isim"),
          gender: findColumn("cinsiyet"),
          oldClass: findColumn("eski sinif"),
          academic: findColumn("akademik basari", "akademik"),
          behavior: findColumn("davranis sorunu", "davranis"),
          notes: findColumn("not", "aciklama"),
        };
        if (
          columns.newClass < 0 ||
          columns.name < 0 ||
          columns.gender < 0 ||
          columns.oldClass < 0 ||
          columns.academic < 0
        ) {
          throw new Error(
            "Bu dosya Sınıf Denge sonuç CSV biçimine uygun değil."
          );
        }

        const records = rows
          .slice(1)
          .map((cells) => ({
            newClass: String(cells[columns.newClass] || "").trim(),
            name: String(cells[columns.name] || "").trim(),
            gender: String(cells[columns.gender] || "")
              .trim()
              .toLocaleUpperCase("tr"),
            oldClass: String(cells[columns.oldClass] || "")
              .trim()
              .toLocaleUpperCase("tr"),
            academic: Academic.normalize(cells[columns.academic]),
            behavior:
              columns.behavior >= 0
                ? Csv.parseBehaviorToken(cells[columns.behavior]) === true
                : false,
            notes:
              columns.notes >= 0
                ? String(cells[columns.notes] || "").trim()
                : "",
          }))
          .filter((record) => record.newClass && record.name);
        if (!records.length) {
          throw new Error("CSV dosyasında geçerli öğrenci bulunamadı.");
        }

        const normalizedNames = records.map((record) =>
          Csv.normalizeHeader(record.name)
        );
        if (new Set(normalizedNames).size !== normalizedNames.length) {
          throw new Error(
            "CSV dosyasında aynı isimle birden fazla öğrenci var."
          );
        }

        const existingMatches = records.map((record) =>
          normalizedStudentMatches(record.name)
        );
        const canUseExisting =
          state.students.length === records.length &&
          existingMatches.every((matches) => matches.length === 1);
        let importedStudents;
        if (canUseExisting) {
          importedStudents = existingMatches.map((matches) => matches[0]);
        } else {
          if (
            state.students.length &&
            !window.confirm(
              "CSV öğrenci listesi mevcut listeyle aynı değil. Öğrenciler CSV dosyasından yeniden oluşturulsun ve mevcut veli istekleri temizlensin mi?"
            )
          ) {
            return;
          }
          importedStudents = records.map((record) => ({
            id: uid("ogr"),
            name: record.name,
            gender:
              record.gender === "E" ||
              record.gender === "ERKEK"
                ? "E"
                : "K",
            oldClass: record.oldClass,
            academic: record.academic,
            behavior: record.behavior,
            notes: record.notes,
          }));
          state.students = importedStudents;
          state.requests = [];
        }

        const classNames = [
          ...new Set(records.map((record) => record.newClass)),
        ];
        const classIndexByName = Object.fromEntries(
          classNames.map((name, index) => [name, index])
        );
        const assignment = {};
        records.forEach((record, index) => {
          assignment[importedStudents[index].id] =
            classIndexByName[record.newClass];
        });

        state.settings.classCount = classNames.length;
        state.settings.classNames = classNames;
        const prefixMatch = classNames[0].match(/^(.*?)[A-Za-zÇĞİÖŞÜ]$/);
        if (prefixMatch && prefixMatch[1]) {
          state.settings.classPrefix = prefixMatch[1];
        }
        state.assignment = assignment;
        Object.keys(classSorts).forEach((key) => delete classSorts[key]);
        saveState();
        renderAll();
        navigate("results");
        showToast(
          `${records.length} öğrencilik önceki sınıf oluşumu yüklendi.`
        );
      } catch (error) {
        showToast(
          error.message || "Önceki sonuç CSV dosyası okunamadı."
        );
      } finally {
        elements.resultCsvInput.value = "";
      }
    };
    reader.readAsText(file, "UTF-8");
  }

  function parseCsv(text) {
    const firstLine = text.split(/\r?\n/, 1)[0] || "";
    const delimiter =
      (firstLine.match(/;/g) || []).length >=
      (firstLine.match(/,/g) || []).length
        ? ";"
        : ",";
    const rows = [];
    let row = [];
    let cell = "";
    let quoted = false;
    for (let index = 0; index < text.length; index += 1) {
      const char = text[index];
      if (char === '"') {
        if (quoted && text[index + 1] === '"') {
          cell += '"';
          index += 1;
        } else {
          quoted = !quoted;
        }
      } else if (char === delimiter && !quoted) {
        row.push(cell);
        cell = "";
      } else if ((char === "\n" || char === "\r") && !quoted) {
        if (char === "\r" && text[index + 1] === "\n") index += 1;
        row.push(cell);
        if (row.some((value) => value.trim())) rows.push(row);
        row = [];
        cell = "";
      } else {
        cell += char;
      }
    }
    row.push(cell);
    if (row.some((value) => value.trim())) rows.push(row);
    return rows;
  }

  function importCsv(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const rows = parseCsv(String(reader.result || ""));
        if (rows.length < 2) throw new Error("CSV dosyasında veri bulunamadı.");
        const headers = rows[0].map(Csv.normalizeHeader);
        const findColumn = (...names) => Csv.findColumn(headers, ...names);
        const columns = {
          name: findColumn("ad soyad", "ad", "isim", "ogrenci"),
          gender: findColumn("cinsiyet"),
          oldClass: findColumn("eski sinif", "sinif", "sube", "eski sube"),
          academic: findColumn(
            "akademik basari",
            "akademik",
            "basari",
            "basari duzeyi"
          ),
          behavior: findColumn(
            "davranis",
            "davranis sorunu",
            "davranis destegi",
            "davranis durumu"
          ),
          notes: findColumn("not", "aciklama", "ogrenci notu"),
        };
        if (
          columns.name < 0 ||
          columns.gender < 0 ||
          columns.oldClass < 0 ||
          columns.academic < 0
        ) {
          throw new Error(
            "Ad Soyad, Cinsiyet, Eski Sınıf ve Akademik Başarı sütunları gereklidir."
          );
        }
        const imported = rows
          .slice(1)
          .map((cells) => {
            const genderRaw = String(cells[columns.gender] || "")
              .trim()
              .toLocaleLowerCase("tr");
            const behaviorRaw =
              columns.behavior >= 0
                ? String(cells[columns.behavior] || "")
                    .trim()
                    .toLocaleLowerCase("tr")
                : "";
            const notesRaw =
              columns.notes >= 0
                ? String(cells[columns.notes] || "").trim()
                : "";
            const behaviorFields = Csv.resolveBehaviorAndNotes(
              behaviorRaw,
              notesRaw
            );
            return {
              id: uid("ogr"),
              name: String(cells[columns.name] || "").trim(),
              gender:
                genderRaw === "e" ||
                genderRaw === "erkek" ||
                genderRaw === "male"
                  ? "E"
                  : "K",
              oldClass: String(cells[columns.oldClass] || "")
                .trim()
                .toLocaleUpperCase("tr"),
              academic: Academic.normalize(cells[columns.academic]),
              behavior: behaviorFields.behavior,
              notes: behaviorFields.notes,
            };
          })
          .filter((student) => student.name && student.oldClass);
        if (!imported.length) {
          throw new Error("Aktarılabilecek geçerli öğrenci bulunamadı.");
        }
        state.students.push(...imported);
        invalidateResult();
        saveState();
        renderAll();
        const behaviorCount = imported.filter(
          (student) => student.behavior
        ).length;
        showToast(
          `${imported.length} öğrenci aktarıldı; ${behaviorCount} öğrenci davranış işaretli.`
        );
      } catch (error) {
        showToast(error.message || "CSV dosyası okunamadı.");
      } finally {
        elements.csvInput.value = "";
      }
    };
    reader.readAsText(file, "UTF-8");
  }

  function createSampleData() {
    const femaleNames = [
      "AYŞE",
      "ELİF",
      "ZEYNEP",
      "DEFNE",
      "EYLÜL",
      "AZRA",
      "NEHİR",
      "DURU",
      "İPEK",
      "YAĞMUR",
      "CEREN",
      "MELİS",
      "ADA",
      "İREM",
      "MİNA",
      "BEREN",
      "SELİN",
      "NAZ",
      "ELA",
      "SUDE",
      "LİNA",
      "ECE",
      "İLAYDA",
      "NİSA",
      "ALARA",
      "MİRAY",
      "DAMLA",
      "AYLİN",
      "ESRA",
      "GİZEM",
      "PELİN",
      "ASYA",
      "DERİN",
      "SENA",
      "MERVE",
      "İDİL",
      "DENİZ",
      "YAREN",
      "CEMRE",
      "MAYA",
      "LAL",
      "BENGİ",
      "İCLAL",
      "NİL",
      "SİMAY",
      "HİRA",
      "ECRİN",
      "ÖYKÜ",
      "TUANA",
      "BESTE",
    ];
    const maleNames = [
      "AHMET",
      "MEHMET",
      "ALİ",
      "ARDA",
      "EMİR",
      "MERT",
      "KEREM",
      "EGE",
      "BORA",
      "DORUK",
      "YİĞİT",
      "ÖMER",
      "KAAN",
      "DENİZ",
      "BURAK",
      "BARAN",
      "UMUT",
      "CAN",
      "OZAN",
      "EREN",
      "ATLAS",
      "TUNA",
      "ONUR",
      "BATUHAN",
      "EMRE",
      "FURKAN",
      "RÜZGAR",
      "ALP",
      "SİNAN",
      "CEM",
      "HAKAN",
      "METE",
      "TOLGA",
      "KUZEY",
      "SERKAN",
      "LEVENT",
      "MİRAN",
      "KORAY",
      "EFE",
      "ARAS",
      "POYRAZ",
      "ÇINAR",
      "TALHA",
      "MURAT",
      "BARIŞ",
      "SARP",
      "KIVANÇ",
      "KUZGUN",
      "YAMAN",
      "TİMUR",
    ];
    const surnameInitials = [
      "Y",
      "D",
      "K",
      "A",
      "Ş",
      "Ç",
      "Ö",
      "T",
      "B",
      "G",
      "S",
      "E",
      "P",
      "U",
      "I",
      "N",
      "M",
      "C",
      "H",
      "R",
    ];
    const students = [];
    const oldClasses = ["4A", "4B", "4C", "4D", "4E", "4F"];
    const oldClassSizes = [34, 34, 33, 33, 33, 33];
    const nameCounters = { K: 0, E: 0 };
    const shortName = (gender) => {
      const pool = gender === "K" ? femaleNames : maleNames;
      const index = nameCounters[gender];
      nameCounters[gender] += 1;
      return `${pool[index % pool.length]} ${
        surnameInitials[Math.floor(index / pool.length) % surnameInitials.length]
      }.`;
    };

    oldClasses.forEach((oldClass, classIndex) => {
      const size = oldClassSizes[classIndex];
      const femaleCount = Math.floor(size / 2) + (classIndex % 2 === 0 ? 1 : 0);
      for (let seat = 0; seat < size; seat += 1) {
        const female = seat < femaleCount;
        const studentIndex = students.length;
        students.push({
          id: `ornek-${String(studentIndex + 1).padStart(3, "0")}`,
          name: shortName(female ? "K" : "E"),
          gender: female ? "K" : "E",
          oldClass,
          academic: ((studentIndex + classIndex) % 3) + 1,
          behavior: studentIndex % 17 === 0 || studentIndex % 43 === 0,
          notes: "",
        });
      }
    });
    const requests = Array.from({ length: 100 }, (_, index) => {
      const subjectIndex = (index * 7) % students.length;
      const subject = students[subjectIndex];
      const type = index % 4 === 0 ? "apart" : "together";
      const targetCount = type === "apart" ? 2 : 5;
      const choices = [];
      for (let offset = 1; choices.length < targetCount; offset += 1) {
        const candidate =
          students[(subjectIndex + offset * 13 + index) % students.length];
        if (candidate.id !== subject.id && !choices.includes(candidate.id)) {
          choices.push(candidate.id);
        }
      }
      return {
        id: `ornek-istek-${index + 1}`,
        studentA: subject.id,
        choices,
        type,
        priority:
          type === "apart"
            ? index % 20 === 0
              ? "hard"
              : "auto"
            : index % 7 === 0
              ? "soft"
              : "auto",
        note: "Örnek veli isteği.",
      };
    });
    return { students, requests };
  }

  function loadSample() {
    if (
      state.students.length &&
      !window.confirm(
        "Mevcut veriler örnek veriyle değiştirilecek. Devam edilsin mi?"
      )
    ) {
      return;
    }
    const sample = createSampleData();
    state = {
      ...defaultState(),
      students: sample.students,
      requests: sample.requests,
      activeView: "students",
    };
    saveState();
    renderAll();
    showToast("200 öğrencilik ve 100 istekli örnek veri yüklendi.");
  }

  function showStartupPrivacyDialog() {
    if (!elements.privacyDialog) return;
    elements.privacyDialog.showModal();
  }

  function clearData() {
    if (
      !window.confirm(
        "Tüm öğrenciler, veli istekleri ve oluşturulan sınıflar silinsin mi?"
      )
    ) {
      return;
    }
    state = defaultState();
    localStorage.removeItem(STORAGE_KEY);
    renderAll();
    showToast("Tüm veriler temizlendi.");
  }

  function bindEvents() {
    document.querySelectorAll(".nav-item").forEach((button) => {
      button.addEventListener("click", () => navigate(button.dataset.view));
    });
    document.querySelectorAll("[data-go]").forEach((button) => {
      button.addEventListener("click", () => navigate(button.dataset.go));
    });
    el("mobileMenu").addEventListener("click", () => {
      document.querySelector(".sidebar").classList.toggle("open");
    });
    el("addStudentButton").addEventListener("click", () =>
      openStudentDialog(null)
    );
    el("emptyAddButton").addEventListener("click", () =>
      openStudentDialog(null)
    );
    elements.studentForm.addEventListener("submit", saveStudent);
    document.querySelectorAll("[data-close-dialog]").forEach((button) => {
      button.addEventListener("click", () => elements.studentDialog.close());
    });
    elements.studentAcademic.addEventListener("input", renderAcademicOutput);
    elements.studentSearch.addEventListener("input", renderStudents);
    elements.oldClassFilter.addEventListener("change", renderStudents);
    elements.studentTableBody.addEventListener("click", (event) => {
      const inlineButton = event.target.closest("[data-inline-edit]");
      const deleteButton = event.target.closest("[data-delete-student]");
      if (inlineButton) openInlineEditor(inlineButton);
      if (deleteButton) deleteStudent(deleteButton.dataset.deleteStudent);
    });
    elements.inlineEditor.addEventListener("submit", saveInlineEdit);
    el("cancelInlineEdit").addEventListener("click", closeInlineEditor);
    document.addEventListener("click", (event) => {
      if (
        !elements.inlineEditor.hidden &&
        !elements.inlineEditor.contains(event.target) &&
        !event.target.closest("[data-inline-edit]")
      ) {
        closeInlineEditor();
      }
    });
    window.addEventListener("resize", closeInlineEditor);
    window.addEventListener("scroll", closeInlineEditor, true);
    elements.requestForm.addEventListener("submit", addRequest);
    el("importRequestCsvButton").addEventListener("click", () =>
      elements.requestCsvInput.click()
    );
    elements.requestCsvInput.addEventListener("change", () =>
      importRequestCsv(elements.requestCsvInput.files[0])
    );
    el("downloadRequestTemplateButton").addEventListener(
      "click",
      downloadRequestTemplate
    );
    elements.requestMatchForm.addEventListener(
      "submit",
      saveMatchedRequests
    );
    elements.requestMatchList.addEventListener("click", (event) => {
      const button = event.target.closest("[data-delete-match-row]");
      if (!button) return;
      deletePendingRequestRow(
        Number(button.dataset.deleteMatchRow)
      );
    });
    elements.requestMatchList.addEventListener("change", (event) => {
      const select = event.target.closest("select");
      if (!select) return;
      if (
        select.classList.contains("match-unresolved") &&
        select.value !== "__unmatched__"
      ) {
        select.classList.remove("match-unresolved");
      }
      clearRequestMatchNotice();
      updateClearUnmatchedChoicesButton();
    });
    elements.clearUnmatchedChoicesButton.addEventListener(
      "click",
      clearUnmatchedRequestChoices
    );
    el("closeRequestMatchDialog").addEventListener("click", () => {
      pendingRequestRows = [];
      clearRequestMatchNotice();
      elements.requestMatchDialog.close();
    });
    el("cancelRequestMatch").addEventListener("click", () => {
      pendingRequestRows = [];
      clearRequestMatchNotice();
      elements.requestMatchDialog.close();
    });
    elements.requestList.addEventListener("click", (event) => {
      const button = event.target.closest("[data-delete-request]");
      if (button) deleteRequest(button.dataset.deleteRequest);
    });
    elements.clearRequestsButton.addEventListener("click", clearRequests);
    elements.requestList.addEventListener("change", (event) => {
      const select = event.target.closest("[data-request-field]");
      if (!select) return;
      updateRequestField(
        select.dataset.requestId,
        select.dataset.requestField,
        select.value
      );
    });
    elements.classCount.addEventListener("change", updateSettings);
    elements.classPrefix.addEventListener("input", updateSettings);
    [
      elements.criterionGender,
      elements.criterionAcademic,
      elements.criterionOldClass,
      elements.criterionSameOldClassGender,
      elements.criterionBehavior,
    ].forEach((select) => {
      select.addEventListener("change", updateSettings);
    });
    elements.solveButton.addEventListener("click", solveClasses);
    el("resolveButton").addEventListener("click", solveClasses);
    el("printButton").addEventListener("click", () => window.print());
    el("exportButton").addEventListener("click", exportResults);
    el("importResultButton").addEventListener("click", () =>
      elements.resultCsvInput.click()
    );
    el("importResultEmptyButton").addEventListener("click", () =>
      elements.resultCsvInput.click()
    );
    elements.resultCsvInput.addEventListener("change", () =>
      importPreviousResult(elements.resultCsvInput.files[0])
    );
    elements.classGrid.addEventListener("click", (event) => {
      const button = event.target.closest("[data-sort-class]");
      if (!button) return;
      classSorts[button.dataset.sortClass] = button.dataset.sortType;
      renderResults();
    });
    elements.classGrid.addEventListener("change", (event) => {
      const select = event.target.closest("[data-move-student]");
      if (select) moveStudent(select.dataset.moveStudent, select.value);
    });
    elements.classGrid.addEventListener("dragstart", (event) => {
      const student = event.target.closest("[data-drag-student]");
      if (!student) return;
      draggedStudentId = student.dataset.dragStudent;
      student.classList.add("dragging");
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", draggedStudentId);
    });
    elements.classGrid.addEventListener("dragend", () => {
      draggedStudentId = null;
      elements.classGrid
        .querySelectorAll(".dragging, .drop-target")
        .forEach((item) =>
          item.classList.remove("dragging", "drop-target")
        );
    });
    elements.classGrid.addEventListener("dragover", (event) => {
      const targetClass = event.target.closest("[data-drop-class]");
      if (!targetClass || !draggedStudentId) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = "move";
      elements.classGrid
        .querySelectorAll(".drop-target")
        .forEach((item) => item.classList.remove("drop-target"));
      targetClass.classList.add("drop-target");
    });
    elements.classGrid.addEventListener("drop", (event) => {
      const targetClass = event.target.closest("[data-drop-class]");
      if (!targetClass) return;
      event.preventDefault();
      const studentId =
        draggedStudentId || event.dataTransfer.getData("text/plain");
      const classIndex = Number(targetClass.dataset.dropClass);
      draggedStudentId = null;
      if (studentId) moveStudent(studentId, classIndex);
    });
    el("importCsvButton").addEventListener("click", () =>
      elements.csvInput.click()
    );
    elements.csvInput.addEventListener("change", () =>
      importCsv(elements.csvInput.files[0])
    );
    el("downloadTemplateButton").addEventListener("click", downloadTemplate);
    el("loadSampleButton").addEventListener("click", loadSample);
    el("clearDataButton").addEventListener("click", clearData);
    elements.privacyDialog.addEventListener("cancel", (event) =>
      event.preventDefault()
    );
    elements.acceptPrivacyButton.addEventListener("click", () =>
      elements.privacyDialog.close()
    );
  }

  bindEvents();
  renderAll();
  showStartupPrivacyDialog();
})();
