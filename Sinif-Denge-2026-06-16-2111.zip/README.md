# Sınıf Denge

Sınıf Denge, öğrencileri yeni şubelere dengeli biçimde dağıtmak için hazırlanmış
kurulumsuz bir web uygulamasıdır. Veriler yalnızca kullanılan tarayıcının yerel
hafızasında saklanır.

## Başlatma

`index.html` dosyasını Chrome, Edge veya Firefox ile açın. Sunucu ya da kurulum
gerekmez.

## Temel kullanım

1. Öğrencileri tek tek ekleyin veya uygulamadaki CSV şablonunu indirip toplu
   aktarım yapın.
   Listedeki öğrenci adı, cinsiyet, eski sınıf, akademik puan, davranış ve not
   alanlarına tıklayarak bilgileri doğrudan değiştirebilirsiniz.
2. Veli İstekleri ekranında öğrencilerin birlikte ya da ayrı olması taleplerini
   girin. Tercihte bulunan öğrenci için en fazla beş kişiyi önem sırasına göre
   seçebilirsiniz. Veli istekleri CSV şablonuyla toplu aktarılabilir; öğrenci
   listesiyle uyuşmayan isimler aktarım sırasında elle eşleştirilebilir.
3. Yeni sınıf sayısını ve ad başlangıcını belirleyin.
4. "Sınıfları oluştur" düğmesine basın.
5. Sonuç ekranındaki uyarıları kontrol edin. Gerekirse öğrencinin yanındaki
   sınıf listesinden elle taşıma yapın veya öğrenci satırını başka sınıf
   kartına sürükleyip bırakın.
6. Sonucu CSV olarak indirin veya yazdırın.

İndirdiğiniz sonuç CSV dosyasını daha sonra Sonuçlar ekranındaki
`Önceki oluşumu içe aktar (CSV)` düğmesiyle yeniden açabilirsiniz. Her sınıf
kartındaki düğmeler öğrencileri kız/erkek, eski sınıf veya akademik duruma göre
görsel olarak sıralar; sınıf atamaları değişmez.

## Denge ölçütleri

- Yeni sınıfların mevcutları arasında en fazla bir öğrenci farkı
- Kız ve erkek öğrenci sayılarının yakınlığı
- Akademik başarı ortalamalarının yakınlığı
- Davranış desteği işaretli öğrencilerin dengeli dağılımı
- Her eski şubeden gelen öğrencilerin yeni şubelere eşit yayılması
- Etkinse her öğrencinin yeni sınıfta eski şubesinden en az bir hemcinsiyle
  birlikte bulunması
- Kesin ve tercih düzeyindeki birlikte/ayrı olma istekleri
- Birbiriyle çelişen kesin istekler için açık uyarı

## İstek öncelikleri

- `Kesin`: Girilen tüm birlikte veya ayrı ilişkileri zorunlu uygular.
- `Otomatik`: Birlikte isteklerinde en uygun bir kişiyi seçer; ayrı
  isteklerinde listedeki herkesle ayrılığı zorunlu tutar.
- `Tercih`: Denge koşulları izin verdiği ölçüde uygulanır.

Dağıtım ayarlarında kız-erkek, akademik başarı, eski şube, kendi sınıfından
hemcinsi ve davranış desteği kriterleri ayrı ayrı etkinleştirilebilir. Etkin
olmayan kriter dağıtım puanına ve uyarılara dahil edilmez.

Dağıtım problemi bazı durumlarda birbiriyle çelişen kurallar içerebilir. Motor
en iyi sonucu arar; karşılanamayan istekleri ve denge sorunlarını sonuç
ekranında açıkça gösterir.

Akademik durum üç seviyeden oluşur: `1 - Desteklenmeli`, `2 - Orta`,
`3 - İyi`.

## Telif ve uyarı

© 2026 Arda Yılmaz. Tüm hakları saklıdır.

Bu uygulama ve sitedeki özgün içerikler Arda Yılmaz’a aittir. İzinsiz olarak
kopyalanamaz, çoğaltılamaz veya başka bir amaçla kullanılamaz.

Bu uygulama geliştirme aşamasındadır ve hata yapabilir.
